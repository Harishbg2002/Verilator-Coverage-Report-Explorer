#!/usr/bin/env python3
"""Project-independent Verilator coverage.dat explorer.

The imported .dat file is the only coverage-data dependency.  No RTL source
files, project hierarchy, simulator Makefile, LCOV, or genhtml are required.
"""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from email.parser import BytesParser
from email.policy import default
import csv
import hashlib
import io
import json
import os
import re
import signal
import threading
import time
import urllib.parse

HERE = Path(__file__).resolve().parent
CFG = json.loads((HERE / "config.json").read_text())
WORKSPACE = (HERE / CFG.get("workspace_dir", "workspace")).resolve()
WORKSPACE.mkdir(parents=True, exist_ok=True)
ACTIVE_STATE = HERE / "active_import.json"
MAX_UPLOAD = int(CFG.get("max_upload_mb", 500)) * 1024 * 1024
API_VERSION = 6

# Verilator 5.x coverage types. "funccov" is accepted as an alias for
# covergroup to accommodate native .dat encodings seen in some releases.
TYPE_ORDER = ["line", "branch", "expr", "toggle", "fsm_state", "fsm_arc",
              "covergroup", "user", "other"]
TYPE_LABELS = {
    "line": "Line", "branch": "Branch", "expr": "Expression",
    "toggle": "Toggle / bit transition", "fsm_state": "FSM state",
    "fsm_arc": "FSM transition", "covergroup": "Covergroup / coverpoint bin",
    "user": "Property / user coverage", "other": "Other coverage record"
}
TYPE_ALIASES = {"funccov": "covergroup", "coverpoint": "covergroup", "bin": "covergroup",
                "fsm_transition": "fsm_arc", "fsm": "fsm_state"}
VECTOR_RE = re.compile(r"(?<![A-Za-z0-9_])\d+\s*'\s*[sS]?[bBoOdDhH]\s*[0-9a-fA-F_xXzZ?]+")

# Browser lifecycle: keep server alive while any explorer tab is open.
LIFECYCLE_LOCK = threading.Lock()
LAST_HEARTBEAT = None
CLOSE_REQUESTED_AT = None
SERVER_INSTANCE = None
HEARTBEAT_TIMEOUT_SECONDS = 180
CLOSE_GRACE_SECONDS = 8
PID_FILE = HERE / "server.pid"
SERVER_STARTED_AT = time.monotonic()
INSTANCE_TOKEN = os.environ.get("COVER_REPORT_INSTANCE_TOKEN", "")
INSTANCE_REGISTRY = Path(os.environ.get("COVER_REPORT_REGISTRY", str(HERE / "active_server.json"))).expanduser()


def safe_name(value):
    value = Path(value).name
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", value)
    return value or "coverage"


def mark_browser_heartbeat():
    global LAST_HEARTBEAT, CLOSE_REQUESTED_AT
    with LIFECYCLE_LOCK:
        LAST_HEARTBEAT = time.monotonic()
        CLOSE_REQUESTED_AT = None


def request_browser_close():
    global CLOSE_REQUESTED_AT
    with LIFECYCLE_LOCK:
        CLOSE_REQUESTED_AT = time.monotonic()


def browser_lifecycle_watchdog():
    while True:
        time.sleep(1)
        now = time.monotonic()
        with LIFECYCLE_LOCK:
            last_heartbeat = LAST_HEARTBEAT
            close_requested = CLOSE_REQUESTED_AT
        should_stop = (close_requested is not None and
                       now - close_requested >= CLOSE_GRACE_SECONDS and
                       (last_heartbeat is None or last_heartbeat <= close_requested))
        idle_stop = ((last_heartbeat is not None and
                      now - last_heartbeat >= HEARTBEAT_TIMEOUT_SECONDS) or
                     (last_heartbeat is None and
                      now - SERVER_STARTED_AT >= HEARTBEAT_TIMEOUT_SECONDS))
        if should_stop or idle_stop:
            print("No active coverage explorer browser session; stopping server.", flush=True)
            if SERVER_INSTANCE is not None:
                SERVER_INSTANCE.shutdown()
            return


def parse_verilator_record(raw, ordinal):
    """Parse one Verilator C-record without consulting source files."""
    if not raw.startswith("C "):
        return None
    first = raw.find("'")
    last = raw.rfind("'")
    if first < 0 or last <= first:
        return None
    tail = raw[last + 1:].strip()
    hit_match = re.search(r"(-?\d+)\s*$", tail)
    if not hit_match:
        return None
    hits = int(hit_match.group(1))
    metadata = raw[first + 1:last]
    fields = {}
    for field in metadata.split("\x01"):
        if "\x02" in field:
            key, value = field.split("\x02", 1)
            fields[key] = value

    raw_type = fields.get("t", "")
    point_type = TYPE_ALIASES.get(raw_type, raw_type if raw_type in TYPE_ORDER else "other")
    file_name = fields.get("f") or fields.get("file") or "(source file not recorded)"
    line_value = fields.get("l", fields.get("line", ""))
    try:
        line = int(line_value) if line_value else None
    except (TypeError, ValueError):
        line = None

    page = fields.get("page", "")
    hierarchy = fields.get("h", fields.get("hier", ""))
    bin_name = fields.get("bin", "")
    comment = fields.get("o") or fields.get("comment") or fields.get("n") or ""

    hierarchy_parts = [x for x in hierarchy.split(".") if x]
    page_tail = page.rsplit("/", 1)[-1] if page else ""
    if point_type == "covergroup":
        if len(hierarchy_parts) >= 3:
            covergroup_name = hierarchy_parts[0]
            coverpoint_name = ".".join(hierarchy_parts[1:-1])
            hierarchy_bin = hierarchy_parts[-1]
        elif len(hierarchy_parts) == 2:
            covergroup_name = page_tail or hierarchy_parts[0]
            coverpoint_name = hierarchy_parts[0]
            hierarchy_bin = hierarchy_parts[1]
        elif len(hierarchy_parts) == 1:
            covergroup_name = page_tail or "Covergroup"
            coverpoint_name = hierarchy_parts[0]
            hierarchy_bin = ""
        else:
            covergroup_name = page_tail or "Covergroup"
            coverpoint_name = fields.get("coverpoint", "")
            hierarchy_bin = ""
        normalized_bin = bin_name or hierarchy_bin or comment or "(unnamed bin)"
        point = " / ".join(x for x in (coverpoint_name, normalized_bin) if x)
        cross_value = fields.get("cross", "").strip().lower()
        cross_flag = cross_value not in ("", "0", "false", "no")
        is_cross = (cross_flag or bool(re.search(r"_x_", coverpoint_name, re.IGNORECASE))
                    or bool(re.search(r"_x_", normalized_bin, re.IGNORECASE)))
        cross_parts = re.split(r"_x_", normalized_bin, flags=re.IGNORECASE) if is_cross and re.search(r"_x_", normalized_bin, re.IGNORECASE) else []
    else:
        covergroup_name = ""
        coverpoint_name = ""
        normalized_bin = bin_name or ""
        is_cross = False
        cross_parts = []
        point = comment or bin_name or hierarchy or fields.get("name") or fields.get("n") or raw_type or point_type

    # Show vector literals only if the .dat metadata itself contains them.
    metadata_text = " ".join(str(v) for v in fields.values())
    vector_literals = VECTOR_RE.findall(metadata_text)
    vector_widths = [re.match(r"\s*(\d+)", value).group(1) for value in vector_literals]

    stable = hashlib.sha1(f"{ordinal}\0{metadata}".encode("utf-8", errors="replace")).hexdigest()[:16]
    detail = {
        "id": stable,
        "file": file_name,
        "type": point_type,
        "raw_type": raw_type,
        "line": line,
        "point": point,
        "hits": hits,
        "fields": fields,
        "page": page,
        "hierarchy": hierarchy,
        "bin": bin_name,
        "raw": raw,
        "covergroup_name": covergroup_name,
        "coverpoint_name": coverpoint_name,
        "normalized_bin": normalized_bin,
        "is_cross": is_cross,
        "cross_parts": cross_parts,
        "vector_literals": vector_literals,
        "vector_widths": vector_widths,
        "metadata_text": metadata_text,
    }
    if point_type == "toggle":
        match = re.match(r"^(.*?)(?:\[(\d+)\])?:(0->1|1->0)$", point)
        if match:
            detail["signal"] = match.group(1)
            detail["bit"] = match.group(2) if match.group(2) is not None else "scalar"
            detail["transition"] = match.group(3)
        else:
            detail["signal"] = point
            detail["bit"] = ""
            detail["transition"] = ""
    return detail


def parse_verilator_dat(path):
    """Return every recognized Verilator coverage point in the selected .dat."""
    points = []
    with Path(path).open("r", errors="replace") as stream:
        for ordinal, raw in enumerate(stream):
            point = parse_verilator_record(raw.rstrip("\r\n"), ordinal)
            if point is not None:
                points.append(point)
    return points


def validate_dat(path):
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Coverage .dat file does not exist: {path}")
    if path.stat().st_size == 0:
        raise ValueError("The selected .dat file is empty.")
    points = parse_verilator_dat(path)
    if not points:
        raise ValueError("No Verilator coverage C-records were found. Select the raw coverage.dat, not an LCOV .info file.")
    return path, points


def activate_dat(source_path, display_name=None):
    source, points = validate_dat(source_path)
    identity = hashlib.sha1((str(source) + str(source.stat().st_mtime_ns)).encode()).hexdigest()[:10]
    stem = safe_name(display_name or source.name)
    work_rel = Path("workspace") / f"{stem}_{identity}"
    work_dir = (HERE / work_rel).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    state = {
        "source_path": str(source),
        "display_name": display_name or source.name,
        "input_type": "verilator_dat",
        "work_dir": work_rel.as_posix(),
        "filtered_data": str(work_dir / f"{stem}.filtered.dat"),
        "exclusions_file": str(work_dir / "coverage_exclusions.json"),
    }
    if not Path(state["exclusions_file"]).exists():
        Path(state["exclusions_file"]).write_text("[]")
    ACTIVE_STATE.write_text(json.dumps(state, indent=2))
    make_filtered_dat(state, load_exclusions(state))
    return state


def load_active():
    if not ACTIVE_STATE.exists():
        return None
    try:
        data = json.loads(ACTIVE_STATE.read_text())
        path = Path(data["source_path"]).resolve()
        if not path.is_file() or data.get("input_type") != "verilator_dat" or "filtered_data" not in data:
            return None
        data["source_path"] = str(path)
        return data
    except (OSError, ValueError, KeyError, TypeError):
        return None


def load_exclusions(state):
    path = Path(state["exclusions_file"])
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return []


def save_exclusions(state, exclusions):
    Path(state["exclusions_file"]).write_text(json.dumps(exclusions, indent=2))


def point_is_excluded(point, exclusions):
    for item in exclusions:
        if item.get("id") == point.get("id"):
            return True
        if item.get("file") == point.get("file") and item.get("start") is not None:
            line = point.get("line")
            if line is not None and int(item["start"]) <= line <= int(item["end"]):
                return True
    return False


def active_points(state):
    return parse_verilator_dat(state["source_path"])


def make_filtered_dat(state, exclusions):
    source = Path(state["source_path"])
    output = Path(state["filtered_data"])
    excluded_ids = {item["id"] for item in exclusions if item.get("id")}
    ranges = [(item["file"], int(item["start"]), int(item["end"]))
              for item in exclusions if item.get("start") is not None]
    out = []
    removed = 0
    with source.open("r", errors="replace") as stream:
        for ordinal, raw in enumerate(stream):
            text = raw.rstrip("\r\n")
            if text.startswith("C "):
                point = parse_verilator_record(text, ordinal)
                if point:
                    drop = point["id"] in excluded_ids
                    if not drop and point.get("line") is not None:
                        drop = any(file_name == point["file"] and start <= point["line"] <= end
                                   for file_name, start, end in ranges)
                    if drop:
                        removed += 1
                        continue
            out.append(text)
    output.write_text("\n".join(out) + "\n")
    return removed


def build_api_data(state):
    points = active_points(state)
    exclusions = load_exclusions(state)
    metrics = {kind: {"total": 0, "covered": 0} for kind in TYPE_ORDER}
    grouped_files = {}
    for point in points:
        kind = point["type"]
        metrics.setdefault(kind, {"total": 0, "covered": 0})
        metrics[kind]["total"] += 1
        if point["hits"] > 0:
            metrics[kind]["covered"] += 1
        file_rec = grouped_files.setdefault(point["file"], {"file": point["file"], "lines": {}, "unmapped": []})
        if point.get("line") is None:
            file_rec["unmapped"].append(point)
        else:
            line_rec = file_rec["lines"].setdefault(point["line"], {"line": point["line"], "hits": None, "points": []})
            line_rec["points"].append(point)
            if kind == "line":
                line_rec["hits"] = point["hits"]

    files = []
    for file_name, record in grouped_files.items():
        lines = []
        for _, line_entry in sorted(record["lines"].items()):
            line_point = next((p for p in line_entry["points"] if p["type"] == "line"), None)
            line_entry["record_label"] = (line_point["point"] if line_point else
                                          "; ".join(p["point"] for p in line_entry["points"][:3]))
            lines.append(line_entry)
        files.append({"file": file_name, "lines": lines, "unmapped": record["unmapped"]})
    files.sort(key=lambda record: record["file"])

    remaining = {kind: {"total": 0, "covered": 0} for kind in metrics}
    for point in points:
        if point_is_excluded(point, exclusions):
            continue
        kind = point["type"]
        remaining.setdefault(kind, {"total": 0, "covered": 0})
        remaining[kind]["total"] += 1
        if point["hits"] > 0:
            remaining[kind]["covered"] += 1

    exclusion_items = [
        {**item, "key": hashlib.sha1(json.dumps(item, sort_keys=True).encode()).hexdigest()}
        for item in exclusions
    ]
    return {
        "source_path": state["source_path"],
        "display_name": state["display_name"],
        "input_type": "verilator_dat",
        "files": files,
        "points": points,
        "metrics": metrics,
        "remaining_metrics": remaining,
        "exclusions": exclusion_items,
        "filtered_data": state["filtered_data"],
        "detail_support": "Coverage types and hierarchy metadata present in the imported Verilator .dat file.",
    }


def build_csv_report(state):
    data = build_api_data(state)
    exclusions = load_exclusions(state)
    out = io.StringIO(newline="")
    writer = csv.writer(out)
    writer.writerow(["Record", "Coverage type", "Source file (from .dat)", "Source line (from .dat)",
                     "Point / state / transition / bin", "Hits", "Status", "Excluded",
                     "Original total", "Original covered", "Remaining total", "Remaining covered",
                     "Hierarchy", "Page", "Covergroup", "Coverpoint or cross", "Bin",
                     "Cross dimensions", "Vector literals present in .dat", "Vector widths", "Raw metadata", "Raw record"])
    for kind in TYPE_ORDER:
        original = data["metrics"].get(kind, {"total": 0, "covered": 0})
        remaining = data["remaining_metrics"].get(kind, {"total": 0, "covered": 0})
        writer.writerow(["SUMMARY", kind, "", "", "", "", "", original["total"] - remaining["total"],
                         original["total"], original["covered"], remaining["total"], remaining["covered"]] + [""] * 10)
    for point in data["points"]:
        excluded = point_is_excluded(point, exclusions)
        status = "Excluded" if excluded else ("Covered" if point["hits"] > 0 else "Uncovered")
        writer.writerow([
            "POINT", point["type"], point["file"], point.get("line", ""), point["point"], point["hits"],
            status, "Yes" if excluded else "No", "", "", "", "", point.get("hierarchy", ""),
            point.get("page", ""), point.get("covergroup_name", ""), point.get("coverpoint_name", ""),
            point.get("bin", ""), " × ".join(point.get("cross_parts", [])),
            ", ".join(point.get("vector_literals", [])), ", ".join(point.get("vector_widths", [])),
            json.dumps(point.get("fields", {}), sort_keys=True), point.get("raw", "")
        ])
    return out.getvalue()


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(HERE), **kwargs)

    def send_json(self, code, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self):
        if self.path == "/api/status":
            state = load_active()
            self.send_json(200, {"active": bool(state),
                                 "source_path": state["source_path"] if state else None,
                                 "display_name": state["display_name"] if state else None,
                                 "input_type": "verilator_dat" if state else None,
                                 "api_version": API_VERSION})
            return
        if self.path == "/api/files":
            state = load_active()
            if not state:
                self.send_json(400, {"error": "Import a raw Verilator coverage .dat file first."})
                return
            try:
                self.send_json(200, build_api_data(state))
            except Exception as exc:
                self.send_json(400, {"error": str(exc)})
            return
        if self.path == "/api/export_report":
            state = load_active()
            if not state:
                self.send_json(400, {"error": "Import a coverage .dat file before extracting the report."})
                return
            try:
                body = build_csv_report(state).encode("utf-8-sig")
                filename = f"{safe_name(Path(state['display_name']).stem)}_coverage_report.csv"
                self.send_response(200)
                self.send_header("Content-Type", "text/csv; charset=utf-8")
                self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as exc:
                self.send_json(500, {"error": f"Could not extract coverage report: {exc}"})
            return
        if self.path == "/api/download_filtered_dat":
            state = load_active()
            if not state:
                self.send_json(400, {"error": "Import a coverage .dat file first."})
                return
            try:
                exclusions = load_exclusions(state)
                make_filtered_dat(state, exclusions)
                body = Path(state["filtered_data"]).read_bytes()
                filename = f"{safe_name(Path(state['display_name']).stem)}.filtered.dat"
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as exc:
                self.send_json(500, {"error": f"Could not create filtered .dat: {exc}"})
            return
        return super().do_GET()

    def _import(self, path, display_name=None):
        state = activate_dat(path, display_name)
        point_count = len(parse_verilator_dat(state["source_path"]))
        self.send_json(200, {"message": f"Verilator coverage database imported: {point_count} records.",
                             "source_path": state["source_path"], "input_type": "verilator_dat"})

    def do_POST(self):
        if self.path == "/api/heartbeat":
            mark_browser_heartbeat()
            self.send_json(200, {"ok": True})
            return
        if self.path == "/api/close":
            request_browser_close()
            self.send_response(204)
            self.end_headers()
            return
        if self.path == "/api/import_path":
            try:
                payload = self.read_json()
                path = str(payload.get("path", "")).strip()
                if not path:
                    raise ValueError("Enter the absolute path to a raw Verilator coverage .dat file.")
                self._import(path)
            except Exception as exc:
                self.send_json(400, {"error": str(exc)})
            return
        if self.path == "/api/import_upload":
            try:
                content_type = self.headers.get("Content-Type", "")
                if "multipart/form-data" not in content_type:
                    raise ValueError("Upload must use multipart/form-data.")
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > MAX_UPLOAD:
                    raise ValueError(f"Upload size must be between 1 byte and {MAX_UPLOAD // (1024 * 1024)} MB.")
                body = self.rfile.read(length)
                envelope = (f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n").encode() + body
                message = BytesParser(policy=default).parsebytes(envelope)
                uploaded, filename = None, "coverage.dat"
                for part in message.iter_parts():
                    if part.get_param("name", header="content-disposition") == "file":
                        uploaded = part.get_payload(decode=True)
                        filename = safe_name(part.get_filename() or filename)
                        break
                if not uploaded:
                    raise ValueError("No file received.")
                if not filename.lower().endswith(".dat"):
                    raise ValueError("Choose a raw Verilator coverage .dat file. LCOV .info files are not accepted in this general mode.")
                imported_dir = WORKSPACE / "imported"
                imported_dir.mkdir(parents=True, exist_ok=True)
                destination = imported_dir / filename
                if destination.exists():
                    destination = imported_dir / f"{destination.stem}_{hashlib.sha1(uploaded).hexdigest()[:8]}{destination.suffix}"
                destination.write_bytes(uploaded)
                self._import(destination, filename)
            except Exception as exc:
                self.send_json(400, {"error": str(exc)})
            return
        if self.path in ("/api/exclude_line", "/api/exclude_point"):
            try:
                state = load_active()
                if not state:
                    raise ValueError("Import a coverage .dat file before applying exclusions.")
                payload = self.read_json()
                exclusions = load_exclusions(state)
                if self.path == "/api/exclude_point":
                    point_id = str(payload.get("id", ""))
                    known_points = {point["id"]: point for point in active_points(state)}
                    if point_id not in known_points:
                        raise ValueError("Selected coverage point is not in the active .dat file.")
                    point = known_points[point_id]
                    item = {"id": point_id, "file": point["file"], "type": point["type"],
                            "line": point.get("line"), "point": point["point"]}
                    if not any(existing.get("id") == point_id for existing in exclusions):
                        exclusions.append(item)
                else:
                    file_name = str(payload.get("file", ""))
                    start, end = int(payload.get("start", 0)), int(payload.get("end", 0))
                    if start < 1 or end < start:
                        raise ValueError("Enter a valid inclusive source-line range.")
                    known_files = {p["file"] for p in active_points(state)}
                    if file_name not in known_files:
                        raise ValueError("Selected source file is not present in the imported .dat file.")
                    item = {"file": file_name, "start": start, "end": end}
                    if item not in exclusions:
                        exclusions.append(item)
                save_exclusions(state, exclusions)
                removed = make_filtered_dat(state, exclusions)
                self.send_json(200, {"message": f"Excluded coverage records updated. {removed} record(s) removed from the filtered copy; the original .dat is unchanged.",
                                     "exclusions": exclusions, "filtered_data": state["filtered_data"]})
            except Exception as exc:
                self.send_json(400, {"error": str(exc)})
            return
        if self.path == "/api/remove_exclusion":
            try:
                state = load_active()
                if not state:
                    raise ValueError("Import a coverage .dat file first.")
                payload = self.read_json()
                key = str(payload.get("key", ""))
                exclusions = load_exclusions(state)
                exclusions = [item for item in exclusions
                              if hashlib.sha1(json.dumps(item, sort_keys=True).encode()).hexdigest() != key]
                save_exclusions(state, exclusions)
                make_filtered_dat(state, exclusions)
                self.send_json(200, {"message": "Selected exclusion removed. Filtered .dat regenerated."})
            except Exception as exc:
                self.send_json(400, {"error": str(exc)})
            return
        if self.path == "/api/clear_exclusions":
            try:
                state = load_active()
                if not state:
                    raise ValueError("Import a coverage .dat file first.")
                save_exclusions(state, [])
                make_filtered_dat(state, [])
                self.send_json(200, {"message": "All exclusions cleared. Filtered .dat restored to the original point set."})
            except Exception as exc:
                self.send_json(400, {"error": str(exc)})
            return
        self.send_json(404, {"error": "Unknown endpoint"})


def _remove_instance_registry():
    try:
        if INSTANCE_REGISTRY.exists():
            record = json.loads(INSTANCE_REGISTRY.read_text())
            if record.get("token") == INSTANCE_TOKEN and int(record.get("pid", -1)) == os.getpid():
                INSTANCE_REGISTRY.unlink(missing_ok=True)
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        pass


def _handle_termination(signum, frame):
    # BaseServer.shutdown() must be called from a thread other than
    # serve_forever(); signal handlers run on the main thread.
    if SERVER_INSTANCE is not None:
        threading.Thread(target=SERVER_INSTANCE.shutdown,
                         name="coverage-signal-shutdown", daemon=True).start()


if __name__ == "__main__":
    host = CFG.get("server_host", "127.0.0.1")
    port = int(os.environ.get("COVERAGE_UI_PORT", os.environ.get("LCOV_UI_PORT", CFG.get("server_port", 8765))))
    default_dat = os.environ.get("COVERAGE_DAT_FILE", "").strip()
    if default_dat:
        try:
            imported = activate_dat(default_dat)
            print(f"Auto-imported Verilator .dat: {imported['source_path']}")
        except Exception as exc:
            print(f"WARNING: Could not auto-import .dat: {exc}")
    server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True
    server.block_on_close = False
    SERVER_INSTANCE = server
    actual_port = int(server.server_address[1])
    os.environ["COVERAGE_UI_PORT"] = str(actual_port)
    PID_FILE.write_text(str(os.getpid()) + "\n")
    try:
        INSTANCE_REGISTRY.parent.mkdir(parents=True, exist_ok=True)
        INSTANCE_REGISTRY.write_text(json.dumps({
            "pid": os.getpid(), "port": actual_port, "token": INSTANCE_TOKEN,
            "server_path": str(Path(__file__).resolve()), "started_at": time.time(),
            "uid": os.getuid() if hasattr(os, "getuid") else None
        }, indent=2))
    except OSError as exc:
        print(f"WARNING: Could not write instance registry: {exc}", flush=True)
    try:
        signal.signal(signal.SIGTERM, _handle_termination)
        signal.signal(signal.SIGINT, _handle_termination)
    except (ValueError, AttributeError):
        pass
    print(f"Verilator Coverage Explorer: http://{host}:{actual_port}", flush=True)
    print("Input dependency: raw coverage.dat only. No project source tree or LCOV tools required.", flush=True)
    print("Original .dat remains read-only; exclusions create a filtered copy.", flush=True)
    threading.Thread(target=browser_lifecycle_watchdog, name="coverage-browser-watchdog", daemon=True).start()
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print("Coverage explorer interrupted; shutting down.", flush=True)
    finally:
        server.server_close()
        try:
            if PID_FILE.exists() and PID_FILE.read_text().strip() == str(os.getpid()):
                PID_FILE.unlink()
        except OSError:
            pass
        _remove_instance_registry()
        print("Coverage explorer server stopped.", flush=True)
