const $ = id => document.getElementById(id);
let current = null;
let expandedLine = null;

function showStatus(message, kind="") { $("status").textContent = message; $("status").className = kind; }
function esc(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
async function api(url, options={}) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function TYPE_LABEL(type) {
  return ({line:"Line",branch:"Branch",expr:"Expression",toggle:"Toggle / bit transition",
    fsm_state:"FSM state",fsm_arc:"FSM transition",covergroup:"Covergroup / bin",
    user:"Property / user coverage",other:"Other coverage record"})[type] || type;
}
function isExcluded(point) {
  return (current?.exclusions || []).some(x => {
    if (x.id && x.id === point.id) return true;
    return x.file === point.file && Number.isInteger(Number(x.start)) && point.line !== null && point.line !== undefined &&
      point.line >= Number(x.start) && point.line <= Number(x.end);
  });
}
function matchesStatus(point) {
  const status = $("statusFilter").value;
  const excluded = isExcluded(point);
  if (status === "excluded") return excluded;
  if (status === "covered") return !excluded && point.hits > 0;
  if (status === "uncovered") return !excluded && point.hits === 0;
  return true;
}
function matchesType(point) { const type = $("typeFilter").value; return type === "all" || point.type === type; }
function pointLabel(point) {
  if (point.type === "toggle") {
    const signal = point.signal || point.point || "signal";
    const bit = point.bit ? `[${point.bit}]` : "";
    return `${signal}${bit}${point.transition ? ` ${point.transition}` : ""}`;
  }
  return point.point || point.hierarchy || point.bin || point.page || TYPE_LABEL(point.type);
}
function statusClass(point) { return point.hits > 0 ? "hit-positive" : "hit-zero"; }
function metricCards() {
  const labels = ["line","branch","expr","toggle","fsm_state","fsm_arc","covergroup","user","other"];
  const remaining = current.remaining_metrics || {};
  const originals = current.metrics || {};
  const html = labels.map(type => {
    const r = remaining[type] || {total:0,covered:0};
    const o = originals[type] || {total:0,covered:0};
    const pct = r.total ? `${(100*r.covered/r.total).toFixed(1)}%` : "—";
    const removed = o.total-r.total;
    return `<button type="button" class="metric" data-metric-type="${type}" title="Show ${esc(TYPE_LABEL(type))} records"><span>${esc(TYPE_LABEL(type))}</span><strong>${pct}</strong><small>${r.covered}/${r.total} covered${removed ? ` · ${removed} excluded` : ""}</small></button>`;
  }).join("");
  $("metrics").innerHTML = html;
  let covered=0,total=0;
  Object.values(remaining).forEach(x => { covered+=x.covered; total+=x.total; });
  $("pointCount").textContent = `${covered}/${total} points covered · ${current.points.length} imported records`;
}
function renderLines() {
  if (!current) return;
  const filename = $("fileSelect").value;
  const record = current.files.find(x => x.file === filename);
  const allLines = record ? record.lines : [];
  const visibleLines = allLines.filter(line => line.points.some(p => matchesType(p) && matchesStatus(p)));
  $("lineCount").textContent = `${visibleLines.length} visible / ${allLines.length} recorded lines`;
  const rows=[];
  for (const line of visibleLines) {
    const points=line.points;
    const shown=points.filter(p => matchesType(p) && matchesStatus(p));
    const excluded=points.length>0 && points.every(isExcluded);
    const isOpen=expandedLine===line.line;
    const covered=points.filter(p=>p.hits>0&&!isExcluded(p)).length;
    const excludedCount=points.filter(isExcluded).length;
    const description=line.record_label || "Coverage record (no source text in .dat)";
    rows.push(`<tr class="source-row${isOpen?" open":""}${excluded?" is-excluded":""}" data-line="${line.line}">
      <td class="line-number">${line.line}</td><td class="line-hits">${line.hits===null?"—":line.hits}</td>
      <td class="source-cell"><div class="line-main"><span class="expand-icon">${isOpen?"▾":"▸"}</span><code>${esc(description)}</code></div><span class="row-note">${covered} covered point(s)${excludedCount?` · ${excludedCount} excluded`:""}</span></td>
      <td><div class="row-actions"><button class="tick ${excluded?"checked":""}" data-exclude-line="${line.line}" title="Exclude all points on line ${line.line}" ${excluded?"disabled":""}>${excluded?"✓":"⊘"}</button></div></td>
    </tr>`);
    if(isOpen) rows.push(`<tr class="detail-row"><td colspan="4"><div class="detail-wrap"><div class="detail-title">Records at ${esc(filename)}:${line.line} — ${shown.length} shown</div>${renderPointTable(shown)}</div></td></tr>`);
  }
  $("lineTable").innerHTML=rows.join("") || '<tr><td colspan="4">No coverage records match the selected filters.</td></tr>';
  renderUnmapped(record);
}
function renderPointTable(points) {
  if(!points.length) return '<p class="hint">No points match the current filters.</p>';
  return `<div class="table-wrap point-wrap"><table class="point-table"><thead><tr><th>Type</th><th>Point / signal / bin</th><th>Hits</th><th>Status</th><th>Exclude</th></tr></thead><tbody>${points.map(p=>{
    const excluded=isExcluded(p);
    const extra=p.type==="toggle"?`<span class="point-sub">Signal: ${esc(p.signal||"—")} · Bit: ${esc(p.bit||"—")} · Transition: ${esc(p.transition||"—")}</span>`:
      `<span class="point-sub">${esc(p.file)}${p.line!==null?`:${p.line}`:""}${p.hierarchy?` · hierarchy: ${esc(p.hierarchy)}`:""}</span>`;
    return `<tr class="${excluded?"point-excluded":""}"><td><span class="type-pill">${esc(TYPE_LABEL(p.type))}</span></td><td class="point-name"><code>${esc(pointLabel(p))}</code>${extra}</td><td class="${statusClass(p)}">${p.hits}</td><td>${excluded?"Excluded":p.hits>0?"Covered":"Uncovered"}</td><td><button class="tick ${excluded?"checked":""}" data-exclude-point="${esc(p.id)}" ${excluded?"disabled":""} title="Exclude this point">${excluded?"✓":"⊘"}</button></td></tr>`;
  }).join("")}</tbody></table></div>`;
}
function renderUnmapped(record) {
  const panel=$("unmappedPanel");
  const points=(record?.unmapped||[]).filter(p=>matchesType(p)&&matchesStatus(p));
  if(!points.length){panel.classList.add("hidden");panel.innerHTML="";return;}
  panel.classList.remove("hidden");
  panel.innerHTML=`<h3>Coverage records without a source line (${points.length})</h3>${renderPointTable(points)}`;
}
function renderFsm(points) {
  const groups = new Map();
  for (const point of points) {
    if (point.type !== "fsm_state" && point.type !== "fsm_arc") continue;
    const key = point.hierarchy || point.file || "FSM (hierarchy not recorded)";
    if (!groups.has(key)) groups.set(key, {name:key, states:[], arcs:[]});
    groups.get(key)[point.type === "fsm_state" ? "states" : "arcs"].push(point);
  }
  if (!groups.size) return '<p class="hint">No native FSM state or transition records exist in this .dat file. The explorer cannot infer missing FSM data.</p>';
  return [...groups.values()].sort((a,b)=>a.name.localeCompare(b.name)).map(group => {
    const states=group.states, arcs=group.arcs;
    const stateRows=states.map(p=>`<tr><td><code>${esc(p.file)}${p.line!==null?`:${p.line}`:""}</code></td><td>${esc(pointLabel(p))}</td><td class="${statusClass(p)}">${p.hits}</td><td>${isExcluded(p)?"Excluded":p.hits>0?"Covered":"Uncovered"}</td><td>${excludeButton(p)}</td></tr>`).join("");
    const arcRows=arcs.map(p=>`<tr><td><code>${esc(p.file)}${p.line!==null?`:${p.line}`:""}</code></td><td>${esc(pointLabel(p))}</td><td class="${statusClass(p)}">${p.hits}</td><td>${isExcluded(p)?"Excluded":p.hits>0?"Covered":"Uncovered"}</td><td>${excludeButton(p)}</td></tr>`).join("");
    let html=`<div class="coverage-group-card"><div class="coverage-group-head"><div><span class="type-pill">Native Verilator FSM</span> <strong>${esc(group.name)}</strong></div><span class="count">States ${states.filter(p=>p.hits>0&&!isExcluded(p)).length}/${states.length} · Arcs ${arcs.filter(p=>p.hits>0&&!isExcluded(p)).length}/${arcs.length}</span></div>`;
    if(states.length||arcs.length) html+=renderDynamicFsmGraph(states,arcs);
    if(states.length) html+=`<h3 class="advanced-heading">FSM states <span class="count">${states.filter(p=>p.hits>0&&!isExcluded(p)).length}/${states.length} covered</span></h3>${fsmTable("State / encoding",stateRows)}`;
    if(arcs.length) html+=`<h3 class="advanced-heading">FSM transitions <span class="count">${arcs.filter(p=>p.hits>0&&!isExcluded(p)).length}/${arcs.length} covered</span></h3>${fsmTable("Transition / arc",arcRows)}`;
    return html+`</div>`;
  }).join("");
}
function fsmTable(label, rows) {
  return `<div class="table-wrap point-wrap"><table class="point-table advanced-table"><thead><tr><th>Source record</th><th>${label}</th><th>Hits</th><th>Status</th><th>Exclude</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function excludeButton(p) {
  const excluded=isExcluded(p);
  return `<button class="tick ${excluded?"checked":""}" data-exclude-advanced-point="${esc(p.id)}" ${excluded?"disabled":""} title="Exclude this point">${excluded?"✓":"⊘"}</button>`;
}
function renderDynamicFsmGraph(states, arcs) {
  const parseArc = point => {
    const label = String(point.point || point.fields?.comment || point.fields?.o || "");
    const match = label.match(/^\s*(.+?)\s*(?:->|=>|→|_TO_)\s*(.+?)\s*$/i);
    return match ? {from:match[1].trim(), to:match[2].trim(), point} : null;
  };
  const parsed = arcs.map(parseArc).filter(Boolean);
  if (!parsed.length) return `<p class="hint">FSM transition records are present. Their labels do not encode parseable source and destination state names, so they are listed in the transition table below rather than connected in a graph.</p>`;
  const stateHits = new Map(states.map(p => [String(pointLabel(p)), p.hits]));
  const names = [...new Set([...states.map(p=>String(pointLabel(p))), ...parsed.flatMap(e=>[e.from,e.to])])];
  if (names.length > 24) return `<p class="hint">${names.length} FSM states were found. The complete state and transition lists are shown below; the graph is omitted to keep large FSMs readable.</p>`;
  const width= Math.max(720, names.length*125), height= Math.max(300, Math.min(620, 190+names.length*12));
  const cx=width/2, cy=height/2, radius=Math.min(width*0.37,height*0.36);
  const nodes=new Map();
  names.forEach((name,index)=>{const angle=-Math.PI/2+2*Math.PI*index/names.length;nodes.set(name,{x:cx+radius*Math.cos(angle),y:cy+radius*Math.sin(angle)});});
  const edgeSvg=parsed.map((edge,index)=>{
    const a=nodes.get(edge.from),b=nodes.get(edge.to);if(!a||!b)return "";
    const hits=edge.point.hits,covered=hits>0;
    const mx=(a.x+b.x)/2,my=(a.y+b.y)/2-12-(index%3)*8;
    return `<g class="fsm-edge ${covered?"covered":"uncovered"}"><path d="M${a.x.toFixed(1)} ${a.y.toFixed(1)} Q${mx.toFixed(1)} ${my.toFixed(1)} ${b.x.toFixed(1)} ${b.y.toFixed(1)}" marker-end="url(#genericFsmArrow)"/><text x="${mx.toFixed(1)}" y="${(my-4).toFixed(1)}" text-anchor="middle">${hits}</text><title>${esc(edge.from)} → ${esc(edge.to)}: ${hits} hits</title></g>`;
  }).join("");
  const nodeSvg=names.map(name=>{
    const pos=nodes.get(name),hits=stateHits.get(name),known=hits!==undefined,covered=known&&hits>0;
    return `<g class="fsm-node ${covered?"covered":"uncovered"}"><rect x="${(pos.x-48).toFixed(1)}" y="${(pos.y-20).toFixed(1)}" width="96" height="40" rx="8"/><text x="${pos.x.toFixed(1)}" y="${(pos.y-2).toFixed(1)}" class="fsm-state-name" text-anchor="middle">${esc(name.length>18?name.slice(0,17)+"…":name)}</text><text x="${pos.x.toFixed(1)}" y="${(pos.y+12).toFixed(1)}" class="fsm-state-hits" text-anchor="middle">${known?`${hits} hits`:"arc endpoint"}</text><title>${esc(name)}: ${known?`${hits} hits`:"state inferred from arc label only"}</title></g>`;
  }).join("");
  return `<div class="fsm-graph-wrap"><div class="fsm-graph-title"><strong>FSM state / transition graph (derived from .dat labels)</strong><span class="hint">Node = state · arrow = arc · labels = hit counts</span></div><div class="table-wrap"><svg class="fsm-graph" style="min-width:0;max-height:none" viewBox="0 0 ${width} ${height}" role="img" aria-label="FSM graph derived from coverage metadata"><defs><marker id="genericFsmArrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0,0 L0,6 L7,3 z" fill="currentColor"/></marker></defs>${edgeSvg}${nodeSvg}</svg></div><p class="hint">Graph edges are drawn only when the .dat point label contains a recognizable state-to-state separator such as →, -&gt;, =&gt; or _TO_. Full records remain listed below.</p></div>`;
}
function fsmTable(label, rows) {
  return `<div class="table-wrap point-wrap"><table class="point-table advanced-table"><thead><tr><th>Source record</th><th>${label}</th><th>Hits</th><th>Status</th><th>Exclude</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function excludeButton(p) {
  const excluded=isExcluded(p);
  return `<button class="tick ${excluded?"checked":""}" data-exclude-advanced-point="${esc(p.id)}" ${excluded?"disabled":""} title="Exclude this point">${excluded?"✓":"⊘"}</button>`;
}
function renderCovergroups(points) {
  const groups=new Map();
  for(const p of points.filter(x=>x.type==="covergroup")) {
    const group=p.covergroup_name||p.page||"Covergroup";
    const cp=p.coverpoint_name||p.hierarchy||"Bins";
    const cross=!!p.is_cross;
    const key=`${p.file}|${group}|${cp}`;
    if(!groups.has(key)) groups.set(key,{file:p.file,group,cp,cross,points:[]});
    groups.get(key).points.push(p);
  }
  return [...groups.values()].sort((a,b)=>`${a.group}.${a.cp}`.localeCompare(`${b.group}.${b.cp}`)).map(g=>{
    const covered=g.points.filter(p=>p.hits>0&&!isExcluded(p)).length;
    const dimensions=Math.max(0,...g.points.map(p=>(p.cross_parts||[]).length));
    const cross=g.cross||dimensions>1;
    const vector=g.points.some(p=>(p.vector_literals||[]).length>0);
    const kind=cross?"Cross coverage":vector?"Vector/value bins":"Coverpoint bins";
    const header=cross?`${Array.from({length:dimensions},(_,i)=>`<th>Dimension ${i+1}</th>`).join("")}<th>Bin combination</th>`:
      `<th>Bin / value label</th><th>Encoded vector literal (if present)</th>`;
    const rows=g.points.map(p=>{
      const parts=p.cross_parts||[];
      const literal=(p.vector_literals||[]).join(", ");
      const meta=p.fields||{};
      const rawValue=[meta.value,meta.val,meta.bin,meta.comment,meta.o,meta.n].filter(Boolean).join(" · ");
      const first=cross?Array.from({length:dimensions},(_,i)=>`<td>${esc(parts[i]||"—")}</td>`).join(""):
        `<td>${esc(p.normalized_bin||p.bin||pointLabel(p))}</td><td>${literal?`<code>${esc(literal)}</code>`:`<span class="point-sub">No vector literal recorded in .dat. Bin metadata: ${esc(rawValue||p.bin||"not available")}</span>`}</td>`;
      const combo=cross?`<td><strong>${esc(parts.length?parts.join(" × "):p.normalized_bin||pointLabel(p))}</strong></td>`:"";
      return `<tr class="${isExcluded(p)?"point-excluded":""}">${first}${combo}<td class="${statusClass(p)}">${p.hits}</td><td>${isExcluded(p)?"Excluded":p.hits>0?"Covered":"Uncovered"}</td><td>${excludeButton(p)}</td></tr>`;
    }).join("");
    return `<div class="coverage-group-card"><div class="coverage-group-head"><div><span class="type-pill">${kind}</span> <strong>${esc(g.cp)}</strong><div class="point-sub">${esc(g.group)} · ${esc(g.file)}</div></div><span class="count">${covered}/${g.points.length} covered</span></div><div class="table-wrap point-wrap"><table class="point-table advanced-table"><thead><tr>${header}<th>Hits</th><th>Status</th><th>Exclude</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
  }).join("");
}
function renderAdvancedPoints() {
  if(!current) return;
  const points=current.points.filter(p=>["fsm_state","fsm_arc","covergroup","user"].includes(p.type)&&matchesStatus(p));
  $("advancedCount").textContent=`${points.length} points`;
  const fsmPoints=points.filter(p=>p.type==="fsm_state"||p.type==="fsm_arc");
  const coverpoints=points.filter(p=>p.type==="covergroup");
  const userPoints=points.filter(p=>p.type==="user");
  let html=renderFsm(fsmPoints);
  if(coverpoints.length) html+=`<h3 class="advanced-heading">Functional covergroups, cross combinations and vector bins <span class="count">${coverpoints.filter(p=>p.hits>0&&!isExcluded(p)).length}/${coverpoints.length} covered</span></h3>${renderCovergroups(coverpoints)}`;
  if(userPoints.length) html+=`<h3 class="advanced-heading">Property / user coverage</h3>${renderPointTable(userPoints)}`;
  if(!html) html='<p class="hint">This .dat file contains no FSM, covergroup or user/property records. Check the instrumentation used to build and run the model.</p>';
  $("advancedPoints").innerHTML=html;
}
function renderExclusions() {
  const items=current?.exclusions||[];
  $("exclusionList").innerHTML=items.length?items.map(x=>{
    const label=x.id?`${TYPE_LABEL(x.type||"other")} · ${x.file}${x.line?`:${x.line}`:""} · ${x.point||x.id}`:`${x.file} · lines ${x.start}-${x.end}`;
    return `<li>${esc(label)}<button class="remove-exclusion" data-remove="${esc(x.key||"")}">Undo</button></li>`;
  }).join(""):"<li>None</li>";
  $("clearBtn").disabled=!current||!items.length;
}
function setImportedView(data) {
  $("activeFile").textContent=`Imported: ${data.source_path}`;
  $("inputMode").textContent="Raw Verilator .dat mode. All displayed coverage and hierarchy fields are parsed from this file; no RTL source lookup is performed.";
}
async function refreshData() {
  const selected=$("fileSelect").value;
  current=await api("/api/files");
  $("fileSelect").disabled=false;$("typeFilter").disabled=false;$("statusFilter").disabled=false;
  $("fileSelect").innerHTML=current.files.map(f=>`<option value="${esc(f.file)}">${esc(f.file)}</option>`).join("");
  if(current.files.some(f=>f.file===selected)) $("fileSelect").value=selected;
  setImportedView(current);
  $("downloadDatBtn").disabled=false;$("extractBtn").disabled=false;
  metricCards();renderLines();renderAdvancedPoints();renderExclusions();
}
async function importPath(path) {
  const result=await api("/api/import_path",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({path})});
  expandedLine=null;await refreshData();showStatus(result.message,"success");
}
async function applyPointExclusion(point) {
  showStatus(`Excluding ${TYPE_LABEL(point.type)} point...`);
  const result=await api("/api/exclude_point",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:point.id})});
  await refreshData();showStatus(result.message,"success");
}
async function applyLineExclusion(line) {
  const file=$("fileSelect").value;
  const result=await api("/api/exclude_line",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({file,start:line,end:line})});
  await refreshData();showStatus(result.message,"success");
}
function downloadBlob(blob, filename) {
  const url=URL.createObjectURL(blob);const link=document.createElement("a");
  link.href=url;link.download=filename;document.body.appendChild(link);link.click();link.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}

$("uploadBtn").addEventListener("click",async()=>{
  const file=$("fileInput").files[0];
  if(!file){showStatus("Choose a raw Verilator coverage.dat file first.","error");return;}
  if(!file.name.toLowerCase().endsWith(".dat")){showStatus("Only .dat files are supported in this general mode.","error");return;}
  const body=new FormData();body.append("file",file);$("uploadBtn").disabled=true;showStatus(`Uploading ${file.name}...`);
  try{const result=await api("/api/import_upload",{method:"POST",body});expandedLine=null;await refreshData();showStatus(result.message,"success");}
  catch(e){showStatus(e.message,"error");}finally{$("uploadBtn").disabled=false;}
});
$("pathImportBtn").addEventListener("click",async()=>{
  const path=$("serverPath").value.trim();if(!path){showStatus("Enter the absolute path to coverage.dat.","error");return;}
  $("pathImportBtn").disabled=true;try{await importPath(path);}catch(e){showStatus(e.message,"error");}finally{$("pathImportBtn").disabled=false;}
});
$("metrics").addEventListener("click",event=>{
  const card=event.target.closest("button[data-metric-type]");if(!card)return;
  $("typeFilter").value=card.dataset.metricType;$("statusFilter").value="all";expandedLine=null;
  const matching=current.files.find(f=>f.lines.some(line=>line.points.some(p=>p.type===card.dataset.metricType))||f.unmapped.some(p=>p.type===card.dataset.metricType));
  if(matching) $("fileSelect").value=matching.file;
  renderLines();renderAdvancedPoints();document.querySelector(".source-table").scrollIntoView({behavior:"smooth",block:"start"});
});
$("fileSelect").addEventListener("change",()=>{expandedLine=null;renderLines();});
$("typeFilter").addEventListener("change",()=>{expandedLine=null;renderLines();});
$("statusFilter").addEventListener("change",()=>{expandedLine=null;renderLines();renderAdvancedPoints();});
$("lineTable").addEventListener("click",async event=>{
  const lineBtn=event.target.closest("button[data-exclude-line]");
  const pointBtn=event.target.closest("button[data-exclude-point]");
  try{
    if(lineBtn&&!lineBtn.disabled){event.stopPropagation();await applyLineExclusion(Number(lineBtn.dataset.excludeLine));return;}
    if(pointBtn&&!pointBtn.disabled){event.stopPropagation();const point=current.points.find(p=>p.id===pointBtn.dataset.excludePoint);if(point)await applyPointExclusion(point);return;}
    const row=event.target.closest("tr.source-row[data-line]");if(row){const line=Number(row.dataset.line);expandedLine=expandedLine===line?null:line;renderLines();}
  }catch(e){showStatus(e.message,"error");}
});
$("advancedPoints").addEventListener("click",async event=>{
  const button=event.target.closest("button[data-exclude-advanced-point]");if(!button||button.disabled)return;
  try{const point=current.points.find(p=>p.id===button.dataset.excludeAdvancedPoint);if(point)await applyPointExclusion(point);}catch(e){showStatus(e.message,"error");}
});
$("unmappedPanel").addEventListener("click",async event=>{
  const button=event.target.closest("button[data-exclude-point]");if(!button||button.disabled)return;
  try{const point=current.points.find(p=>p.id===button.dataset.excludePoint);if(point)await applyPointExclusion(point);}catch(e){showStatus(e.message,"error");}
});
$("exclusionList").addEventListener("click",async event=>{
  const button=event.target.closest("button[data-remove]");if(!button)return;
  try{await api("/api/remove_exclusion",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({key:button.dataset.remove})});await refreshData();showStatus("Exclusion undone and filtered .dat regenerated.","success");}
  catch(e){showStatus(e.message,"error");}
});
$("refreshBtn").addEventListener("click",async()=>{try{await refreshData();showStatus("Coverage data refreshed.","success");}catch(e){showStatus(e.message,"error");}});
$("clearBtn").addEventListener("click",async()=>{
  try{const result=await api("/api/clear_exclusions",{method:"POST"});await refreshData();showStatus(result.message,"success");}
  catch(e){showStatus(e.message,"error");}
});
$("extractBtn").addEventListener("click",async()=>{
  const button=$("extractBtn");button.disabled=true;showStatus("Preparing CSV coverage report...");
  try{const response=await fetch("/api/export_report");if(!response.ok){let message=`Report extraction failed (${response.status})`;try{message=(await response.json()).error||message;}catch(_){}throw new Error(message);}
    const disposition=response.headers.get("Content-Disposition")||"";const match=disposition.match(/filename="?([^";]+)"?/i);
    downloadBlob(await response.blob(),match?match[1]:"coverage_report.csv");showStatus("Coverage report extracted as CSV.","success");}
  catch(e){showStatus(e.message,"error");}finally{button.disabled=!current;}
});
$("downloadDatBtn").addEventListener("click",async()=>{
  const button=$("downloadDatBtn");button.disabled=true;showStatus("Preparing filtered coverage.dat...");
  try{const response=await fetch("/api/download_filtered_dat");if(!response.ok){let message=`Download failed (${response.status})`;try{message=(await response.json()).error||message;}catch(_){}throw new Error(message);}
    const disposition=response.headers.get("Content-Disposition")||"";const match=disposition.match(/filename="?([^";]+)"?/i);
    downloadBlob(await response.blob(),match?match[1]:"coverage.filtered.dat");showStatus("Filtered coverage.dat downloaded. Original file unchanged.","success");}
  catch(e){showStatus(e.message,"error");}finally{button.disabled=!current;}
});

function sendHeartbeat(){fetch("/api/heartbeat",{method:"POST",keepalive:true}).catch(()=>{});}
sendHeartbeat();const heartbeatTimer=setInterval(sendHeartbeat,5000);
window.addEventListener("pagehide",()=>{clearInterval(heartbeatTimer);try{navigator.sendBeacon("/api/close",new Blob([],{type:"text/plain"}));}catch(_){}});
(async()=>{try{const status=await api("/api/status");if(status.active)await refreshData();}catch(e){showStatus(e.message,"error");}})();
